﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ActionFilter.Controllers
{
    public class HomeController : Controller
    {
      
        [MyActionFilter(Property1 = "Value1", Property2 = "Value2")]
        public ActionResult Index()
        {
            return View();
        }

       // [MyActionFilter(Property1 = filterContext.HttpContext.Request.Params["test"], Property2 = "Value2")]
        [MyActionFilter(Property1 = "", Property2 = "Value2")]
        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}